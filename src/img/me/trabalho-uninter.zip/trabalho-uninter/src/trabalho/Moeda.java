package trabalho;

public abstract class Moeda { 
	
	protected double valor;
	
	public abstract void info();
	public abstract double converter();

}
